 const appointments = [];
  
  export default appointments;